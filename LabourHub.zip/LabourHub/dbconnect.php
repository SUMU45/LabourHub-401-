<?php
	
	$host = 'localhost';
	$username= 'root';
	$pass = '';
	$db = 'labours_hub';
	
	$con=new mysqli($host, $username, $pass, $db) or die("not connected");
?>